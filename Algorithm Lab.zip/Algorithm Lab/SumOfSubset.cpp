#include <iostream>
#include <algorithm> // sort ফাংশনের জন্য
using namespace std;

const int MAX_N = 100;

int n;                
int w[MAX_N];         
int x[MAX_N];         
int m;                

void SumOfSub(int s, int k, int r) {
    x[k] = 1; 
    if (s + w[k] == m) {
        for (int i = 1; i <= k; ++i) {
            if (x[i] == 1) {
                cout << w[i] << " ";
            }
        }
        cout << endl;
    } else if (s + w[k] + w[k + 1] <= m) {
        SumOfSub(s + w[k], k + 1, r - w[k]);
    }

    if ((s + r - w[k] >= m) && (s + w[k + 1] <= m)) {
        x[k] = 0;
        SumOfSub(s, k + 1, r - w[k]);
    }
}

int main() {
    cout << "Enter the number of elements in the set: ";
    cin >> n;

    cout << "Enter the elements of the set in increasing or decreasing order: ";
    for (int i = 1; i <= n; ++i) {
        cin >> w[i];
    }

 // ম্যানুয়ালি বর্ধমান ক্রমে সাজানোর জন্য বাবল সোর্ট
for (int i = 1; i <= n; ++i) {
    for (int j = 1; j <= n - i; ++j) {
        if (w[j] > w[j + 1]) { 
            // দুটি উপাদানের মান অদল-বদল
            int temp = w[j];
            w[j] = w[j + 1];
            w[j + 1] = temp;
        }
    }
}


    cout << "Enter the target sum: ";
    cin >> m;

    int total = 0;
    for (int i = 1; i <= n; ++i) {
        total += w[i];
    }

    cout << "Subsets that sum to " << m << ":\n";
    SumOfSub(0, 1, total);

    return 0;
}