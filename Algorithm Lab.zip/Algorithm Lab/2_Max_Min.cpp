#include <iostream>
using namespace std;

// Function to find max and min in an array segment a[i..j]
void MaxMin(int a[], int i, int j, int &max, int &min) {
    if (i == j) { // Single element case
        max = min = a[i];
    } 
    else if (i == j - 1) { // Two elements case
        if (a[i] < a[j]) {
            max = a[j];
            min = a[i];
        } else {
            max = a[i];
            min = a[j];
        }
    } 
    else { // More than two elements, divide and conquer
        int mid = (i + j) / 2; // Midpoint
        int max1, min1;

        // Solve the two subproblems
        MaxMin(a, i, mid, max, min);
        MaxMin(a, mid + 1, j, max1, min1);

        // Combine solutions
        if (max1 > max) max = max1;
        if (min1 < min) min = min1;
    }
}

int main() {
    int n;
    cout << "Enter the number of elements in the array: ";
    cin >> n;

    int a[n];
    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    int max, min;
    MaxMin(a, 0, n - 1, max, min);

    cout << "Maximum element: " << max << endl;
    cout << "Minimum element: " << min << endl;

    return 0;
}
