#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 10; // Maximum number of jobs
int d[N], j[N], p[N];

int JS(int d[], int j[], int n, int &maxProfit) {
    //Sort jobs by profit in descending order (Bubble Sort)
    for (int i = 1; i <= n; i++) {
        for (int k = 1; k < n; k++) {
            if (p[k] < p[k + 1]) {
                swap(p[k], p[k + 1]);
                swap(d[k], d[k + 1]);
            }
        }
    }

    // Initialize job sequence and other variables
    d[0] = 0, j[0] = 0;
    j[1] = 1; // Include job 1
    maxProfit = p[1]; // Start with the profit of the first job
    int k = 1; // Number of jobs in the solution

    for (int i = 2; i <= n; ++i) {
        int r = k; // r is the last position of the job sequence

        // Check feasibility of inserting job i
        while ((d[j[r]] > d[i]) && (d[j[r]] != r)) {
            r = r - 1;
        }

        if ((d[j[r]] <= d[i]) && (d[i] > r)) {
            // Insert job i into the sequence
            for (int q = k; q >= r + 1; q--) {
                j[q + 1] = j[q];
            }
            j[r + 1] = i;
            k = k + 1;
            maxProfit += p[i]; // Add the profit of the included job
        }
    }

    return k; // Return the number of jobs included
}

int main() {
    int n;
    cout << "Enter the number of jobs: ";
    cin >> n;

    cout << "Enter the profits of the jobs:\n";
    for (int i = 1; i <= n; i++) {
        cin >> p[i];
    }

    cout << "Enter the deadlines of the jobs:\n";
    for (int i = 1; i <= n; i++) {
        cin >> d[i];
    }

    int maxProfit = 0; // Variable to store maximum profit
    int k = JS(d, j, n, maxProfit);

    cout << "Maximum Profit: " << maxProfit << endl;
    cout << "Number of jobs included: " << k << endl;

    cout << "Job sequence: ";
    for (int i = 1; i <= k; i++) {
        cout << j[i] << " ";
    }
    cout << endl;

    return 0;
}