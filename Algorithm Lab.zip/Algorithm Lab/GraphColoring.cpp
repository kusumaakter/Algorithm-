#include <iostream>
using namespace std;

const int MAX_N = 20;  //max number of vertices in the graph

int n;  //store vertices
int m;  //maximum color
int e;  //store edges

int G[MAX_N][MAX_N]; 
int x[MAX_N];

void writeSolution() {   
    for (int i = 1; i <= n; ++i) 
        cout << x[i] << " ";
    cout << endl;
}

void NextValue(int k) {
    do {
        x[k] = (x[k] + 1) % (m + 1); 
        if (x[k] == 0) //no valid color so backtracking start
         return;
        int j;
        for (j = 1; j <= n; ++j) { 
            if (G[k][j] != 0 && x[k] == x[j])  //both vertices have the same color
                break;
        }
        if (j == n + 1) return;
    } while (true);
}

void mColoring(int k) {
    do {
        NextValue(k);
        if (x[k] == 0) return;  
        if (k == n) 
            writeSolution();
        else
            mColoring(k + 1); 
    } while (true);
}

int main() {
    cout << "Enter the number of vertices: ";
    cin >> n;
    cout << "Enter the number of edges: ";
    cin >> e;
    cout << "Enter the maximum number of colors: ";
    cin >> m;

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            G[i][j] = 0;  //no edges initially
        }
        x[i] = 0;  //no colors assigned initially
    }

    cout << "Enter the edges (u v) where u and v are vertices:\n";
    for (int i = 0; i < e; ++i) {
        int u, v;
        cin >> u >> v;
        G[u][v] = 1;
        G[v][u] = 1; 
    }

    cout << "All possible colorings:\n";
    mColoring(1); 
    return 0;
}