#include <bits/stdc++.h>
using namespace std;

#define MAX 100

int Prim(int cost[MAX][MAX], int n, int t[MAX][2]) {
    int near[MAX];
    int mincost = 0;

    //Find (k, l) - an edge of minimum cost in E
    int k = -1, l = -1;
    int min = INT_MAX;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (i != j && cost[i][j] < min) { 
                min = cost[i][j];
                k = i;
                l = j;
            }
        }
    }

    mincost = cost[k][l];
    t[1][1] = k;
    t[1][2] = l;

    //Initialize near array
    for (int i = 1; i <= n; ++i) {
        if (cost[i][k] < cost[i][l]) {
            near[i] = k;
        } else {
            near[i] = l;
        }
    }
    near[k] = near[l] = 0;

    //Find n-2 additional edges for t
    for (int i = 2; i <= n - 1; ++i) {
        // Find j such that near[j] != 0 and cost[j][near[j]] is minimum
        int j = -1;
        int min = INT_MAX;
        for (int m = 1; m <= n; ++m) {
            if (near[m] != 0 && cost[m][near[m]] < min) {
                min = cost[m][near[m]];
                j = m;
            }
        }

        t[i][1] = j;
        t[i][2] = near[j];
        mincost = mincost + cost[j][near[j]];
        near[j] = 0;

        for (int k = 1; k <= n; ++k) {
            if (near[k] != 0 && cost[k][near[k]] > cost[k][j]) {
                near[k] = j;
            }
        }
    }

    return mincost;
}

int main() {
    int n, e;
    cout << "Enter the number of vertices: ";
    cin >> n;
    cout << "Enter the number of edges: ";
    cin >> e;

    int cost[MAX][MAX];
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cost[i][j] = (i == j) ? INT_MAX : INT_MAX; 
        }
    }

    cout << "Enter edges (u, v) and their cost:\n";
    for (int i = 0; i < e; i++) {
        int u, v, c;
        cin >> u >> v >> c;
        cost[u][v] = c;
        cost[v][u] = c; 
    }

    int t[MAX][2]; 
    int mincost = Prim(cost, n, t);

    cout << "Edges in the Prim's Minimum Cost Spanning Tree and Their Cost :\n";
    for (int i = 1; i <= n - 1; ++i) {
        cout << "(" << t[i][1] << " , " << t[i][2] << ") = "<<cost[t[i][1]][t[i][2]]<<endl;
    }
    cout << "Prim's Minimum cost: " << mincost << endl;

    return 0;
}
