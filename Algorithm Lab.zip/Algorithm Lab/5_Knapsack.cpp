#include <bits/stdc++.h>
using namespace std;

float x[100];  
int w[100];    
int p[100];
int indices[100];

void sortItems(int n) {
    for (int i = 0; i < n; i++) {
        indices[i] = i;
    }
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if ((float)p[j] / w[j] < (float)p[j + 1] / w[j + 1]) {
                swap(p[j], p[j + 1]);
                swap(w[j], w[j + 1]);
                swap(indices[j], indices[j + 1]);
            }
        }
    }
}

float GreedyKnapsack(int n, int m) {
    sortItems(n);
    int u = m; 
    float sum = 0.0;

    for (int i = 0; i < n; i++) {
        x[i] = 0.0;
    }

    for (int i = 0; i < n; i++) {
        if (w[i] <= u) {
            x[indices[i]] = 1;
            sum += p[i];
            u -= w[i];
        } else {
            x[indices[i]] = (float)u / w[i];
            sum += x[indices[i]] * p[i];
            break;
        }
    }

    return sum;
}

int main() {
    int m, n;

    cout << "Enter the number of items: ";
    cin >> n;
    cout << "Enter the capacity of the knapsack: ";
    cin >> m;

    cout << "Profits: ";
    for (int i = 0; i < n; i++) {
        cin >> p[i];
    }

    cout << "Weights: ";
    for (int i = 0; i < n; i++) {
        cin >> w[i];
    }

    float maxProfit = GreedyKnapsack(n, m);

    cout << "Maximum profit: " << maxProfit << endl;

    // Print solution vector in the original order
    cout << "Solution vector (fractions of items taken in original order): ";
    for (int i = 0; i < n; i++) {
        cout << x[i] << " ";
    }
    cout << endl;

    return 0;
}
