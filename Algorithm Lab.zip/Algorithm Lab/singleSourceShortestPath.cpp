// #include <bits/stdc++.h>
// using namespace std;


// void ShortestPaths(int v, int n, int cost[][100], int dist[], bool S[]) {
//     for (int i = 1; i <= n; ++i) {
//         S[i] = false;
//         dist[i] = cost[v][i];
//     }

//     S[v] = true;
//     dist[v] = 0;

//     for (int num = 2; num <= n; ++num) {
//         int u = -1;
//         int minDist = INT_MAX;

//         for (int i = 1; i <= n; ++i) {
//             if (!S[i] && dist[i] < minDist) {
//                 minDist = dist[i];
//                 u = i;
//             }
//         }

//         if (u == -1) break;  
//         S[u] = true;

//         for (int w = 1; w <= n; ++w) {
//             if (!S[w] && cost[u][w] != INT_MAX && dist[u] + cost[u][w] < dist[w]) {
//                 dist[w] = dist[u] + cost[u][w];
//             }
//         }
//     }
// }

// int main() {
//     int n, m;
//     cout << "Enter the number of vertices: ";
//     cin >> n;
//     cout << "Enter the number of directed edges: ";
//     cin >> m;

//     int cost[100][100]; 

//     for (int i = 1; i <= n; ++i) {
//         for (int j = 1; j <= n; ++j) {
//             if (i == j)
//                 cost[i][j] = 0;
//             else
//                 cost[i][j] = INT_MAX;
//         }
//     }

//     cout << "Enter the edges (u v w) where u is the source, v is the destination, and w is the weight:\n";
//     for (int i = 0; i < m; ++i) {
//         int u, v, w;
//         cin >> u >> v >> w;
//         cost[u][v] = w;
//     }

//     int dist[100];
//     bool S[100];
//     int startVertex;
//     cout << "Enter the start vertex (1-based): ";
//     cin >> startVertex;



//     ShortestPaths(startVertex, n, cost, dist, S);

//     cout << "Vertex\tDistance from Source\n";
//     for (int i = 1; i <= n; ++i) {
//         if (dist[i] == INT_MAX)
//             cout << i << "\tINF\n";
//         else
//             cout << i << "\t" << dist[i] << "\n";
//     }

//     return 0;
// }

#include <bits/stdc++.h>
using namespace std;

void ShortestPaths(int v, int n, int cost[][100], int dist[], bool S[], int parent[]) {
    for (int i = 1; i <= n; ++i) {
        S[i] = false;
        dist[i] = cost[v][i];
        parent[i] = (cost[v][i] != INT_MAX && i != v) ? v : -1; // Initialize parent
    }

    S[v] = true;
    dist[v] = 0;   

    for (int num = 2; num <= n; ++num) {
        int u = -1;
        int minDist = INT_MAX;

        for (int i = 1; i <= n; ++i) {
            if (!S[i] && dist[i] < minDist) {
                minDist = dist[i];
                u = i;
            }
        }

        if (u == -1) break; 
        S[u] = true;

        for (int w = 1; w <= n; ++w) {
            if (!S[w] && cost[u][w] != INT_MAX && dist[u] + cost[u][w] < dist[w]) {
                dist[w] = dist[u] + cost[u][w];
                parent[w] = u; // Update parent
            }
        }
    }
}

void PrintPath(int vertex, int parent[]) {
    if (vertex == -1) return;
    PrintPath(parent[vertex], parent);
    cout << vertex << " ";
}

int main() {
    int n, m;
    cout << "Enter the number of vertices: ";
    cin >> n;
    cout << "Enter the number of directed edges: ";
    cin >> m;

    int cost[100][100];
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            if (i == j) {
                cost[i][j] = 0;
            } else {
                cost[i][j] = INT_MAX;
            }
        }
    }

    cout << "Enter the edges (u v w) where u is the source, v is the destination, and w is the weight:\n";
    for (int i = 0; i < m; ++i) {
        int u, v, w;
        cin >> u >> v >> w;
        cost[u][v] = w;
    }

    int dist[100];
    bool S[100];
    int parent[100];
    int startVertex;
    cout << "Enter the start vertex (1-based): ";
    cin >> startVertex;

    ShortestPaths(startVertex, n, cost, dist, S, parent);

    cout << "Vertex\tDistance from Source\tPath Line\n";
    for (int i = 1; i <= n; ++i) {
        cout << i << "\t\t";
        if (dist[i] == INT_MAX) {
            cout << "INF\t\t\t\t-\n";
        } else {
            cout << dist[i] << "\t\t\t\t";
            PrintPath(i, parent);
            cout << "\n";
        }
    }

    return 0;
}