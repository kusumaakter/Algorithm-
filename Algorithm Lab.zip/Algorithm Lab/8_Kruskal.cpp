// #include <iostream>
// #include <climits>
// using namespace std;

// #define INF 999 // Replacing infinity with 999

// void primMST(int cost[7][7], int n) {
//     int near[7]; // Tracks the nearest vertex for each vertex
//     int t[6][2]; // To store edges of the MST (n-1 edges)
//     int minCost = 0;

//     // Step 1: Find the minimum edge
//     int min = INF, u = -1, v = -1;
//     for (int i = 0; i < n; i++) {
//         for (int j = 0; j < n; j++) {
//             if (cost[i][j] < min) {
//                 min = cost[i][j];
//                 u = i;
//                 v = j;
//             }
//         }
//     }

//     // Add the minimum edge to MST
//     t[0][0] = u;
//     t[0][1] = v;
//     minCost += cost[u][v];

//     // Step 2: Initialize the `near` array
//     for (int i = 0; i < n; i++) {
//         if (cost[i][u] < cost[i][v]) {
//             near[i] = u;
//         } else {
//             near[i] = v;
//         }
//     }
//     near[u] = near[v] = -1; // u and v are now part of the MST

//     // Step 3: Find the remaining n-2 edges
//     for (int i = 1; i < n - 1; i++) {
//         int min = INF, k = -1;
//         for (int j = 0; j < n; j++) {
//             if (near[j] != -1 && cost[j][near[j]] < min) {
//                 min = cost[j][near[j]];
//                 k = j;
//             }
//         }

//         t[i][0] = k;
//         t[i][1] = near[k];
//         minCost += cost[k][near[k]];
//         near[k] = -1; // k is now part of the MST

//         // Update the `near` array
//         for (int j = 0; j < n; j++) {
//             if (near[j] != -1 && cost[j][k] < cost[j][near[j]]) {
//                 near[j] = k;
//             }
//         }
//     }

//     // Print the result
//     cout << "Minimum cost: " << minCost << endl;
//     cout << "Edges in the MST:" << endl;
//     for (int i = 0; i < n - 1; i++) {
//         cout << "(" << t[i][0] + 1 << ", " << t[i][1] + 1 << ") = " << cost[t[i][0]][t[i][1]] << endl;
//     }
// }

// int main() {
//     int n = 7; // Number of vertices
//     int cost[7][7] = {
//         {INF, 28, INF, INF, INF, 10, INF},
//         {28, INF, 16, INF, INF, INF, 14},
//         {INF, 16, INF, 12, INF, INF, INF},
//         {INF, INF, 12, INF, 22, INF, 18},
//         {INF, INF, INF, 22, INF, 25, 24},
//         {10, INF, INF, INF, 25, INF, INF},
//         {INF, 14, INF, 18, 24, INF, INF}
//     };

//     primMST(cost, n);

//     return 0;
// }

#include <iostream>
#include <limits.h>
using namespace std;

#define INF INT_MAX // Representation of infinity

void Prim(int cost[10][10], int n, int t[10][2]) {
    int near[10]; // Array to keep track of the nearest vertex
    int mincost = 0;

    // Step 1: Find the edge (k, l) of minimum cost in the graph
    int k, l, min = INF;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (cost[i][j] < min) {
                min = cost[i][j];
                k = i;
                l = j;
            }
        }
    }

    // Add this edge to the MST
    t[1][1] = k;
    t[1][2] = l;
    mincost += cost[k][l];

    // Initialize near array
    for (int i = 1; i <= n; i++) {
        if (cost[i][k] < cost[i][l])
            near[i] = k;
        else
            near[i] = l;
    }

    near[k] = 0;
    near[l] = 0;

    // Step 2: Find n-2 additional edges for the MST
    for (int i = 2; i <= n - 1; i++) {
        int min = INF, j;

        // Find the vertex j such that cost[j][near[j]] is minimum
        for (int u = 1; u <= n; u++) {
            if (near[u] != 0 && cost[u][near[u]] < min) {
                j = u;
                min = cost[u][near[u]];
            }
        }

        // Add the edge to the MST
        t[i][1] = j;
        t[i][2] = near[j];
        mincost += cost[j][near[j]];
        near[j] = 0;

        // Update the near array
        for (int u = 1; u <= n; u++) {
            if (near[u] != 0 && cost[u][near[u]] > cost[u][j]) {
                near[u] = j;
            }
        }
    }

    cout << "Minimum cost: " << mincost << endl;
    cout << "Edges in the MST:" << endl;
    for (int i = 1; i <= n - 1; i++) {
        cout << "(" << t[i][0] << ", " << t[i][1] << ")  =  " << endl;
    }
}

int main() {
    int n, cost[10][10], t[10][2];

    cout << "Enter the number of vertices: ";
    cin >> n;

    cout << "Enter the cost adjacency matrix (use " << INF << " for no edge):" << endl;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cin >> cost[i][j];
        }
    }

    Prim(cost, n, t);

    return 0;
}
