#include <iostream>
using namespace std;

// Function to interchange a[i] with a[j]
void Interchange(int a[], int i, int j) {
    int temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}

// Partition function to rearrange elements
int Partition(int a[], int m, int p) {
    int v = a[m];
    int i = m;
    int j = p;

    do {
        do {
            i = i + 1;
        } while (a[i] < v); // Find element >= v

        do {
            j = j - 1;
        } while (a[j] > v); // Find element <= v

        if (i < j) {
            Interchange(a, i, j);
        }
    } while (i < j);

    a[m] = a[j];
    a[j] = v;

    return j; // Return partition index
}

// QuickSort function
void QuickSort(int a[], int p, int q) {
    if (p < q) {
        // Partition the array and get the pivot index
        int j = Partition(a, p, q + 1);

        // Recursively sort the subarrays
        QuickSort(a, p, j - 1);
        QuickSort(a, j + 1, q);
    }
}

// Driver function to test the QuickSort algorithm
int main() {
    int arr[] = {12, 3, 9, 15, 6, 10, 1};
    int n = sizeof(arr) / sizeof(arr[0]);

    cout << "Original array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    // Perform QuickSort
    QuickSort(arr, 0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
