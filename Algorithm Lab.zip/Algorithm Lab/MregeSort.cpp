#include<bits/stdc++.h>
using namespace std;
int const N =10e7;
int a[N];
int b[N];

//Merge function
void Merge(int low,int mid, int high){
    int h = low;
    int i = low;
    int j = mid + 1;

    while(h <= mid && j<= high){
        if(a[h] <= a[j]){
            b[i]= a[h];
            h++;
        }else{
            b[i]= a[j];
            j++;
        }
        i++;
    }
    if(h>mid){
        for(int k=j;k<=high;k++){
            b[i]=a[k];
            i++;
        }
    }else{
        for(int k=h;k<=mid;k++){
            b[i]=a[k];
            i++;
        }
    }
    for(int k=low;k<=high;k++){
        a[k]=b[k];
    }
}

void MergeSort(int low, int high){
    if(low<high){
        int mid = (low+high)/2;
        MergeSort(low,mid);
        MergeSort(mid+1,high);
        Merge(low,mid,high);

    }
}

int main(){
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    cout << "Enter " << n << " elements: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    MergeSort(0,n-1);
    cout << "Sorted Array: ";
    for (int i = 0; i < n; i++) {
        cout << a[i] << ' ';
    }

    return 0;
}