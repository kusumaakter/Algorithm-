// #include <bits/stdc++.h>
// using namespace std;

// // Structure to represent a job
// struct Job {
//     int id;       // Job ID
//     int deadline; // Deadline of the job
//     int profit;   // Profit associated with the job
// };

// // Comparator function to sort jobs in decreasing order of profit
// bool compare(Job a, Job b) {
//     return a.profit > b.profit;
// }

// // Function to perform job sequencing
// int JobSequencing(Job jobs[], int result[], int deadlines[], int n, int &maxProfit) {
//     // Sort jobs in decreasing order of profit
//     sort(jobs, jobs + n, compare);

//     // Initialize the deadlines and result arrays
//     memset(deadlines, 0, sizeof(int) * (n + 1)); // Mark deadlines as unoccupied
//     memset(result, 0, sizeof(int) * (n + 1));    // Initialize result array

//     deadlines[1] = 1;    // Include the first job
//     result[1] = jobs[0].id;
//     maxProfit = jobs[0].profit; // Start with the first job's profit

//     int k = 1; // Number of jobs included

//     for (int i = 2; i <= n; i++) {
//         int r = k;

//         // Find feasible position for job[i] in non-increasing order of deadlines
//         while ((deadlines[result[r]] > jobs[i - 1].deadline) && (deadlines[result[r]] != r))
//             r--;

//         if ((deadlines[result[r]] <= jobs[i - 1].deadline) && (jobs[i - 1].deadline > r)) {
//             // Insert job[i] into the result
//             for (int q = k; q >= r + 1; q--) {
//                 result[q + 1] = result[q];
//             }
//             result[r + 1] = jobs[i - 1].id;
//             deadlines[result[r + 1]] = jobs[i - 1].deadline;
//             k++;
//             maxProfit += jobs[i - 1].profit; // Add profit of the included job
//         }
//     }

//     return k;
// }

// int main() {
//     int n; // Number of jobs
//     cout << "Enter the number of jobs: ";
//     cin >> n;

//     Job jobs[n];
//     cout << "Enter job ID, deadline, and profit for each job:\n";
//     for (int i = 0; i < n; i++) {
//         cin >> jobs[i].id >> jobs[i].deadline >> jobs[i].profit;
//     }

//     int result[n + 1] = {0};     // Array to store the job sequence
//     int deadlines[n + 1] = {0};  // Array to manage deadlines
//     int maxProfit = 0;           // Variable to store the maximum profit

//     int maxJobs = JobSequencing(jobs, result, deadlines, n, maxProfit);

//     cout << "Maximum number of jobs: " << maxJobs << "\n";
//     cout << "Job sequence: ";
//     for (int i = 1; i <= maxJobs; i++) {
//         cout << result[i] << " ";
//     }
//     cout << "\n";
//     cout << "Maximum profit: " << maxProfit << "\n";

//     return 0;
// }

#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int j[N], d[N], p[N], ans[N];

int JS(int n, int &numJobs) {
    d[0] = j[0] = 0; // Initialize
    int profit = p[1];
    j[1] = 1;
    ans[1] = 1; // Store the first job in the answer array
    numJobs = 1;

    int k = 1; // Number of jobs included
    for (int i = 2; i <= n; ++i) {
        int r = k;

        // Find the feasible position for job[i]
        while (d[j[r]] > d[i] && d[j[r]] != r)
            r--;

        if (d[j[r]] <= d[i] && d[i] > r) {
            // Insert job[i] into the sequence
            for (int q = k; q >= r + 1; q--)
                j[q + 1] = j[q];
            j[r + 1] = i;

            ans[++numJobs] = i; // Add the job to the answer array
            profit += p[i];
            k++;
        }
    }
    return profit;
}

int main() {
    int n;
    cout << "Enter the number of jobs: ";
    cin >> n;

    cout << "Enter the profits of the jobs:\n";
    for (int i = 1; i <= n; ++i) {
        cin >> p[i];
    }

    cout << "Enter the deadlines of the jobs:\n";
    for (int i = 1; i <= n; ++i) {
        cin >> d[i];
    }

    int numJobs = 0;
    int profit = JS(n, numJobs);

    cout << "Profit: " << profit << endl;

    cout << "Jobs Taken: ";
    for (int i = 1; i <= numJobs; ++i)
        cout << ans[i] << " ";
    cout << endl;

    cout << "Job sequence is: ";
    for (int i = 1; i <= n; ++i)
        if (j[i] != 0) // Only display valid jobs
            cout << j[i] << " ";
    cout << endl;

    return 0;
}
