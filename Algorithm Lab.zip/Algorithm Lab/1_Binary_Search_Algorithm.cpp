#include <iostream>
using namespace std;

// Recursive Binary Search Algorithm
int BinSearchRecursive(int arr[], int low, int high, int x) {
    if (low > high) return 0; // Element not found

    int mid = (low + high) / 2;

    if (x == arr[mid]) return mid + 1; // Return 1-based index
    else if (x < arr[mid])
        return BinSearchRecursive(arr, low, mid - 1, x);
    else
        return BinSearchRecursive(arr, mid + 1, high, x);
}

int main() {
    int arr[] = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20}; // Sorted dataset
    int n = sizeof(arr) / sizeof(arr[0]);
    int x;

    cout << "Data set: ";
    for (int i = 0; i < n; i++) cout << arr[i] << " ";
    cout << endl;

    cout << "Enter the number to search (Recursive): ";
    cin >> x;

    int result = BinSearchRecursive(arr, 0, n - 1, x);

    if (result != 0)
        cout << "Element found at position " << result << "." << endl;
    else
        cout << "Element not found." << endl;

    return 0;
}