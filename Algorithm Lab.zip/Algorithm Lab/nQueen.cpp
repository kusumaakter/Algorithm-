#include <bits/stdc++.h>
using namespace std;


// Global array to store the column positions of queens
int x[100];


// Function to check if a queen can be placed at position (k, i)
bool Place(int k, int i) {
    for (int j = 1; j <= k - 1; j++) {
        // Check if two queens are in the same column or on the same diagonal
        if (x[j] == i || abs(x[j] - i) == abs(j - k)) {
            return false; // Invalid position
        }
    }
    return true; // Valid position
}


// Backtracking function to find all solutions
void NQueens(int k, int n) {
    for (int i = 1; i <= n; i++) {
        if (Place(k, i)) {
            x[k] = i; // Place the queen at row k, column i


            if (k == n) {
                // All queens are placed, print the solution
               
                // 1. Numerical Output
                cout << "Numerical Solution: ";
                for (int j = 1; j <= n; j++) {
                    cout << x[j] << " "; // Print column positions of queens
                }
                cout << endl;


                // 2. Graphical Output
                cout << "Graphical Solution:\n";
                for (int row = 1; row <= n; row++) {
                    for (int col = 1; col <= n; col++) {
                        if (x[row] == col) {
                            cout << "Q "; // Queen position
                        } else {
                            cout << ". "; // Empty cell
                        }
                    }
                    cout << endl; // Newline for the next row
                }
                cout << endl;
            } else {
                // Recur to place queens in the next row
                NQueens(k + 1, n);
            }
        }
    }
    cout<<"Backtracking Start at Row : "<<k<<endl;
}


int main() {
    int n;
    cout << "Enter the value of n number of queens : ";
    cin >> n;


    if (n < 1) {
        cout << "Invalid input! The size of the board must be at least 1." << endl;
        return 0;
    }


    NQueens(1, n); // Start placing queens from row 1


    return 0;
}
