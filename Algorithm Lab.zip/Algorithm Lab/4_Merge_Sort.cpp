#include <iostream>
using namespace std;

// Global arrays
const int MAX_SIZE = 1000;
int a[MAX_SIZE], b[MAX_SIZE];

// Merge function: merges two sorted subarrays
void Merge(int low, int mid, int high) {
    int h = low, i = low, j = mid + 1;

    // Merge the two subarrays
    while (h <= mid && j <= high) {
        if (a[h] <= a[j]) {
            b[i] = a[h];
            h++;
        } else {
            b[i] = a[j];
            j++;
        }
        i++;
    }

    // Copy remaining elements from the left subarray
    if (h > mid) {
        for (int k = j; k <= high; k++) {
            b[i] = a[k];
            i++;
        }
    } else {
        for (int k = h; k <= mid; k++) {
            b[i] = a[k];
            i++;
        }
    }

    // Copy merged elements back to the original array
    for (int k = low; k <= high; k++) {
        a[k] = b[k];
    }
}

// MergeSort function: recursively sorts the array
void MergeSort(int low, int high) {
    if (low < high) {
        // Find the midpoint
        int mid = (low + high) / 2;

        // Recursively sort both halves
        MergeSort(low, mid);
        MergeSort(mid + 1, high);

        // Merge the sorted halves
        Merge(low, mid, high);
    }
}

int main() {
    int n;

    cout << "Enter the number of elements: ";
    cin >> n;

    if (n > MAX_SIZE) {
        cout << "Error: Array size exceeds maximum allowed size of " << MAX_SIZE << "." << endl;
        return 1;
    }

    cout << "Enter the elements of the array: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    MergeSort(0, n - 1);

    cout << "Sorted array: ";
    for (int i = 0; i < n; i++) {
        cout << a[i] << " ";
    }
    cout << endl;

    return 0;
}
