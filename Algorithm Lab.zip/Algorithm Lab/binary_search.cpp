// // 1. Max-Min Algorithm using Divide & Conquer method
// #include <bits/stdc++.h>
// using namespace std;
// // Function to find maximum and minimum
// void MaxMin(int arr[], int i, int j, int &max, int &min)
// {
//     if (i == j)
//     {
//         max = min = arr[i];
//     }
//     else if (i == j - 1)
//     {
//         if (arr[i] < arr[j])
//         {
//             max = arr[j];
//             min = arr[i];
//         }
//         else
//         {
//             max = arr[i];
//             min = arr[j];
//         }
//     }
//     else
//     {
//         int mid = (i + j) / 2;
//         int max1, min1;
//         MaxMin(arr, i, mid, max, min);
//         MaxMin(arr, mid + 1, j, max1, min1);
//         if (max < max1)
//         {
//             max = max1;
//         }
//         if (min > min1)
//         {
//             min = min1;
//         }
//     }
// }
// int main()
// {
//     int n;
//     cout << "Enter the number of elements in the array: ";
//     cin >> n;
//     int arr[n];
//     cout << "Enter " << n << " elements: ";
//     for (int i = 0; i < n; i++)
//     {
//         cin >> arr[i];
//     }
//     int max, min;

//     MaxMin(arr, 0, n - 1, max, min);
//     cout << "Maximum element: " << max << endl;
//     cout << "Minimum element: " << min << endl;
//     return 0;
// }
// //2. Quick Sort algorithm using the divide &
// conquer method
// #include <bits/stdc++.h>
// using namespace std;
// const int N = 1e7;
// int a[N];
// void interchange(int i, int j) {
//  int temp = a[i];
//  a[i] = a[j];
//  a[j] = temp;
// }
// // Partition function
// int partition(int m, int p) {
//  int v = a[m];
//  int i = m + 1;
//  int j = p;
//  do {
//  while (i <= p && a[i] < v) {
//  i++;
//  }
//  while (a[j] > v) {
//  j--;
//  }
//  if (i < j) {
//  interchange(i, j);
//  }
//  } while (i < j);
//  interchange(m, j);
//  return j;
// }
// void QuickSort(int m, int p) {
//  if (m < p) {
//  int q = partition(m, p);
//  QuickSort(m, q - 1);
//  QuickSort(q + 1, p);
//  }
// }
// int main() {
//  int n;
//  cout << "Enter the number of elements: ";
//  cin >> n;
//  cout << "Enter " << n << " elements: ";
//  for (int i = 0; i < n; i++) {
//  cin >> a[i];
//  }
//  QuickSort(0, n - 1);
//  cout << "Sorted Array: ";
//  for (int i = 0; i < n; i++) {
//  cout << a[i] << ' ';
//  }
//  return 0;
// }
// //3. Merge Sort algorithm using divide &
// conquer method
// #include<bits/stdc++.h>
// using namespace std;
// int const N =10e7;
// int a[N];
// int b[N];
// //Merge function
// void Merge(int low,int mid, int high){
//  int h = low;
//  int i = low;
//  int j = mid + 1;
//  while(h <= mid && j<= high){
//  if(a[h] <= a[j]){
//  b[i]= a[h];
//  h++;
//  }else{
//  b[i]= a[j];
//  j++;
//  }
//  i++;
//  }
//  if(h>mid){
//  for(int k=j;k<=high;k++){
//  b[i]=a[k];
//  i++;
//  }
//  }else{
//  for(int k=h;k<=mid;k++){
//  b[i]=a[k];
//  i++;
//  }
//  }
//  for(int k=low;k<=high;k++){
//  a[k]=b[k];
//  }
// }
// void MergeSort(int low, int high){
//  if(low<high){
//  int mid = (low+high)/2;
//  MergeSort(low,mid);
//  MergeSort(mid+1,high);
//  Merge(low,mid,high);
//  }
// }
// int main(){
//  int n;
//  cout << "Enter the number of elements: ";
//  cin >> n;
//  cout << "Enter " << n << " elements: ";
//  for (int i = 0; i < n; i++) {
//  cin >> a[i];
//  }
//  MergeSort(0,n-1);
//  cout << "Sorted Array: ";
//  for (int i = 0; i < n; i++) {
//  cout << a[i] << ' ';
//  }
//  return 0;
// }
// //4. Greedy Knapsack Problem using greedy
// method
// #include <bits/stdc++.h>
// using namespace std;
// float x[100];
// int w[100];
// int p[100];
// int indices[100];
// void sortItems(int n) {
//  for (int i = 0; i < n; i++) {
//  indices[i] = i;
//  }
//  for (int i = 0; i < n - 1; i++) {
//  for (int j = 0; j < n - i - 1; j++) {
//  if ((float)p[j] / w[j] < (float)p[j + 1] / w[j
// + 1]) {
//  swap(p[j], p[j + 1]);
//  swap(w[j], w[j + 1]);
//  swap(indices[j], indices[j + 1]);
//  }
//  }
//  }
// }
// float GreedyKnapsack(int n, int m) {
//  sortItems(n);
//  int u = m;
//  float sum = 0.0;
//  for (int i = 0; i < n; i++) {
//  x[i] = 0.0;
//  }
//  for (int i = 0; i < n; i++) {
//  if (w[i] <= u) {
//  x[indices[i]] = 1;
//  sum += p[i];
//  u -= w[i];
//  } else {
//  x[indices[i]] = (float)u / w[i];
//  sum += x[indices[i]] * p[i];
//  break;
//  }
//  }
//  return sum;
// }
// int main() {
//  int m, n;
//  cout << "Enter the number of items: ";
//  cin >> n;
//  cout << "Enter the capacity of the
// knapsack: ";
//  cin >> m;
//  cout << "Profits: ";
//  for (int i = 0; i < n; i++) {
//  cin >> p[i];
//  }
//  cout << "Weights: ";
//  for (int i = 0; i < n; i++) {
//  cin >> w[i];
//  }
//  float maxProfit = GreedyKnapsack(n, m);
//  cout << "Maximum profit: " << maxProfit
// << endl;
//  // Print solution vector in the original order
//  cout << "Solution vector (fractions of
// items taken in original order): ";
//  for (int i = 0; i < n; i++) {
//  cout << x[i] << " ";
//  }
//  cout << endl;
//  return 0;
// }
// 5. Job Sequence problem with deadlines
// using greedy method
// #include <bits/stdc++.h>
// using namespace std;
// const int N = 1e5 + 10;
// int j[N], d[N], p[N];
// // Function to perform Job Scheduling and
// return the total profit
// int JS(int d[], int j[], int n)
// {
//  d[0] = j[0] = 0;
//  int profit = p[1];
//  j[1] = 1;
//  int k = 1; // Number of jobs taken
//  // Process each job to check if it can be
// included in the job sequence
//  for (int i = 2; i <= n; ++i)
//  {
//  int r = k;
//  // Find where to place job i in the
// sequence
//  while (d[j[r]] > d[i] && d[j[r]] != r)
//  r--;
//  if (d[j[r]] <= d[i] && d[i] > r)
//  {
//  // Insert job i at position r
//  for (int q = k; q >= r + 1; q--)
//  j[q + 1] = j[q];
//  j[r + 1] = i;
//  profit += p[i];
//  k++;
//  }
//  }
//  return profit;
// }
// int main()
// {
//  int n;
//  cout<<"Enter the number of jobs : ";
//  cin >> n;
//  // Input profits of the jobs
//  cout<<"Enter the Profits : \n";
//  for (int i = 1; i <= n; ++i)
//  {
//  cin >> p[i];
//  }
//  // Input deadlines of the jobs
//  cout<<"Enter the Deadlines : \n";
//  for (int i = 1; i <= n; ++i)
//  {
//  cin >> d[i];
//  }
//  // Call the job scheduling function and get
// the profit
//  int profit = JS(d, j, n);
//  // Output the total profit
//  cout << "Maximum Profit: " << profit <<
// endl;
// int JobInclude =0;
//  for(int i=0;i<=n;++i)
//  {
//  if(j[i]!=0)
//  JobInclude++;
//  }
//  cout<<"Total Job Included :
// "<<JobInclude<<endl;
//  // Output the job sequence in the order
// they were scheduled (from 1 to n)
//  cout << "Job sequence is: ";
//  for (int i = 1; i <= n; ++i)
//  {
//  if (j[i] != 0) // Only print jobs that were
// included in the sequence
//  cout << j[i] << " ";
//  }
//  cout << endl;
//  return 0;
// }
// 6. All Pair Shortest path problem graph
// using dynamic Programming
// #include<bits/stdc++.h>
// using namespace std;
// const int MAX_N = 1000;
// int cost[MAX_N][MAX_N];
// int A[MAX_N][MAX_N];
// void AllPaths(int cost[MAX_N][MAX_N], int
// A[MAX_N][MAX_N], int n) {
//  for (int i = 0; i < n; ++i) {
//  for (int j = 0; j < n; ++j) {
//  A[i][j] = cost[i][j];
//  }
//  }
//  for (int k = 0; k < n; ++k) {
//  for (int i = 0; i < n; ++i) {
//  for (int j = 0; j < n; ++j) {
//  if (A[i][k] != INT_MAX && A[k][j] !=
// INT_MAX) {
//  A[i][j] = min(A[i][j], A[i][k] +
// A[k][j]);
//  }
//  }
//  }
//  }
// }
// int main() {
//  int n, m;
//  cout << "Enter the number of vertices: ";
//  cin >> n;
//  cout << "Enter the number of directed
// edges: ";
//  cin >> m;
//  for (int i = 0; i < n; ++i) {
//  for (int j = 0; j < n; ++j) {
//  if (i == j)
//  cost[i][j] = 0;
//  else
//  cost[i][j] = INT_MAX;
//  }
//  }
//  cout << "Enter each edge in the format: u
// to v and their cost :\n";
//  for (int i = 0; i < m; ++i) {
//  int u, v, c;
//  cin >> u >> v >> c;
//  cost[u - 1][v - 1] = c;
//  }
//  cout<<"\nA-0 matrix:\n";
//  for (int i = 0; i < n; ++i) {
//  for (int j = 0; j < n; ++j) {
//  if (cost[i][j] == INT_MAX)
//  cout << "INF";
//  else
//  cout << cost[i][j] << " ";
//  }
//  cout << endl;
//  }
//  cout<<endl;
//  AllPaths(cost, A, n);
//  cout << "The matrix of shortest path costs
// :\n";
//  for (int i = 0; i < n; ++i) {
//  for (int j = 0; j < n; ++j) {
//  if (A[i][j] == INT_MAX)
//  cout << "INF";
//  else
//  cout << A[i][j] << " ";
//  }
//  cout << endl;
//  }
//  return 0;
// }
// 7. Single Source shortest path problem with a deadlines using greedy method
#include <bits/stdc++.h>
using namespace std;
const int INF = INT_MAX; // Infinite distance representation
void ShortestPaths(int v, int cost[][100], int dist[], int n)
{
    bool S[100];     // Local visited set
    int parent[100]; // Local parent array
                     // Initialize distance, set S to false, and parent for all vertices
    for (int i = 1; i <= n; ++i)
    {
        S[i] = false;
        dist[i] = cost[v][i];
        parent[i] = (cost[v][i] != INF && i != v) ? v : -1; // Initialize parent
    }
    S[v] = true;    // Include source vertex in S
    dist[v] = 0;    // Distance to source itself is 0
    parent[v] = -1; // Source vertex has no parent
    for (int num = 2; num <= n; ++num)
    {
        int u = -1, minDist = INF;
        // Find the vertex u not in S with the minimum dist[u]
        for (int i = 1; i <= n; ++i)
        {
            if (!S[i] && dist[i] < minDist)
            {
                minDist = dist[i];
                u = i;
            }
        }
        if (u == -1)
            break;   // No more reachable vertices
        S[u] = true; // Include u in S
        // Update distances for neighbors of u
        for (int w = 1; w <= n; ++w)
        {
            if (!S[w] && cost[u][w] != INF &&
                dist[u] + cost[u][w] < dist[w])
            {
                dist[w] = dist[u] + cost[u][w];
                parent[w] = u; // Update parent for path
            }
        }
    }
    // Display distances and paths
    cout << "Vertex\tDistance from Source\tPath Line\n ";
    for (int i = 1; i <= n; ++i)
    {
        cout << i << "\t\t";
        if (dist[i] == INF)
        {
            cout << "INF\t\t\t\t-\n"; // If no path exists
        }
        else
        {
            cout << dist[i] << "\t\t\t\t";
            // Print the path for the current vertex
            int path[100];      // Array to store the path
            int pathLength = 0; // Path length tracker
            // Trace the path back using the parent array
            for (int cur = i; cur != -1; cur = parent[cur])
            {
                path[pathLength++] = cur;
            }
            // Print the path in reverse order
            for (int j = pathLength - 1; j >= 0; --j)
            {
                cout << path[j] << " ";
            }
            cout << "\n";
        }
    }
}
int main()
{
    int n, m;
    cout << "Enter the number of vertices: ";
    cin >> n;
    cout << "Enter the number of directed edges : ";
    cin >> m;
    int cost[100][100], dist[100];
    // Initialize the adjacency matrix with INF
    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= n; ++j)
        {
            if (i == j)
            {
                cost[i][j] = 0; // Distance to itself is 0
            }
            else
            {
                cost[i][j] = INF; // Distance to others is initially infinite
            }
        }
    }
    cout << "Enter the edges (u v w) where u is the source,v is the destination, and w is the weight :\n ";
    for (int i = 0; i < m; ++i)
    {
        int u, v, w;
        cin >> u >> v >> w;
        cost[u][v] = w; // Set weight for edge u -> v
    }
    int source;
    cout << "Enter the start vertex (1-based): ";
    cin >> source;
    // Call the shortest path function
    ShortestPaths(source, cost, dist, n);
    return 0;
}
// //8. Sum Of Subset using Backtracking
// strategy
// #include <iostream>
// #include <algorithm> // sort ফ াংশনের জেয
// using namespace std;
// const int MAX_N = 100;
// int n;
// int w[MAX_N];
// int x[MAX_N];
//int m;
// void SumOfSub(int s, int k, int r) {
//  x[k] = 1;
//  if (s + w[k] == m) {
//  for (int i = 1; i <= k; ++i) {
//  if (x[i] == 1) {
//  cout << w[i] << " ";
//  }
//  }
//  cout << endl;
//  } else if (s + w[k] + w[k + 1] <= m) {
//  SumOfSub(s + w[k], k + 1, r - w[k]);
//  }
//  if ((s + r - w[k] >= m) && (s + w[k + 1] <=
// m)) {
//  x[k] = 0;
//  SumOfSub(s, k + 1, r - w[k]);
//  }
// }
// int main() {
//  cout << "Enter the number of elements in
// the set: ";
//  cin >> n;
//  cout << "Enter the elements of the set in
// increasing or decreasing order: ";
//  for (int i = 1; i <= n; ++i) {
//  cin >> w[i];
//  }
// // ম্য েুয় লি বর্ ধম্ ে ক্রনম্ স জ নে র জেয
// ব বি সস র্ধ
// for (int i = 1; i <= n; ++i) {
//  for (int j = 1; j <= n - i; ++j) {
//  if (w[j] > w[j + 1]) {
//  // দুটর্ উপ দ নের ম্ ে অদি-বদি
//  int temp = w[j];
//  w[j] = w[j + 1];
//  w[j + 1] = temp;
//  }
//  }
// }
//  cout << "Enter the target sum: ";
//  cin >> m;
//  int total = 0;
//  for (int i = 1; i <= n; ++i) {
//  total += w[i];
//  }
//  cout << "Subsets that sum to " << m <<
// ":\n";
//  SumOfSub(0, 1, total);
//  return 0;
// }
// //9. NQueens problem using backtracking
// #include <bits/stdc++.h>
// using namespace std;
// // Global array to store the column positions
// of queens
// int x[100];
// // Function to check if a queen can be
// placed at position (k, i)
// bool Place(int k, int i) {
//  for (int j = 1; j <= k - 1; j++) {
//  // Check if two queens are in the same
// column or on the same diagonal
//  if (x[j] == i || abs(x[j] - i) == abs(j - k)) {
//  return false; // Invalid position
//  }
//  }
//  return true; // Valid position
// }
// // Backtracking function to find all solutions
// void NQueens(int k, int n) {
//  for (int i = 1; i <= n; i++) {
//  if (Place(k, i)) {
//  x[k] = i; // Place the queen at row k,
// column i
//  if (k == n) {
//  // All queens are placed, print the
// solution

//  // 1. Numerical Output
//  cout << "Numerical Solution: ";
//  for (int j = 1; j <= n; j++) {
//  cout << x[j] << " "; // Print
// column positions of queens
//  }
//  cout << endl;
//  // 2. Graphical Output
//  cout << "Graphical Solution:\n";
//  for (int row = 1; row <= n; row++) {
//  for (int col = 1; col <= n; col++)
// {
//  if (x[row] == col) {
//  cout << "Q "; // Queen
// position
//  } else {
//  cout << ". "; // Empty cell
//  }
//  }
//  cout << endl; // Newline for the
// next row
//  }
//  cout << endl;
//  } else {
//  // Recur to place queens in the
// next row
//  NQueens(k + 1, n);
//  }
//  }
//  }
//  cout<<"Backtracking Start at Row :
// "<<k<<endl;
// }
// int main() {
//  int n;
//  cout << "Enter the value of n number of
// queens : ";
//  cin >> n;
//  if (n < 1) {
//  cout << "Invalid input! The size of the
// board must be at least 1." << endl;
//  return 0;
//  }
//  NQueens(1, n); // Start placing queens
// from row 1
//  return 0;
// }
// //10. Graph Coloring using backtracking
// #include <iostream>
// using namespace std;
// const int MAX_N = 20; //max number of
// vertices in the graph
// int n; //store vertices
// int m; //maximum color
// int e; //store edges
// int G[MAX_N][MAX_N];
// int x[MAX_N];
// void writeSolution() {
//  for (int i = 1; i <= n; ++i)
//  cout << x[i] << " ";
//  cout << endl;
// }
// void NextValue(int k) {
//  do {
//  x[k] = (x[k] + 1) % (m + 1);
//  if (x[k] == 0) //no valid color so
// backtracking start
//  return;
//  int j;
//  for (j = 1; j <= n; ++j) {
//  if (G[k][j] != 0 && x[k] == x[j]) //both
// vertices have the same color
//  break;
//  }
//  if (j == n + 1) return;
//  } while (true);
// }
// void mColoring(int k) {
//  do {
//  NextValue(k);
//  if (x[k] == 0) return;
//  if (k == n)
//  writeSolution();
//  else
//  mColoring(k + 1);
//  } while (true);
// }
// int main() {
//  cout << "Enter the number of vertices: ";
//  cin >> n;
//  cout << "Enter the number of edges: ";
//  cin >> e;
//  cout << "Enter the maximum number of
// colors: ";
//  cin >> m;
//  for (int i = 1; i <= n; ++i) {
//  for (int j = 1; j <= n; ++j) {
//  G[i][j] = 0; //no edges initially
//  }
//  x[i] = 0; //no colors assigned initially
//  }
//  cout << "Enter the edges (u v) where u
// and v are vertices:\n";
//  for (int i = 0; i < e; ++i) {
//  int u, v;
//  cin >> u >> v;
//  G[u][v] = 1;
//  G[v][u] = 1;
//  }
//  cout << "All possible colorings:\n";
//  mColoring(1);
//  return 0;
// }
// //11. The minimum cost spanning tree using
// Prim's Algorithm
// #include <bits/stdc++.h>
// using namespace std;
// #define MAX 100
// int Prim(int cost[MAX][MAX], int n, int
// t[MAX][2]) {
//  int near[MAX];
//  int mincost = 0;
//  //Find (k, l) - an edge of minimum cost in
// E
//  int k = -1, l = -1;
//  int min = INT_MAX;
//  for (int i = 1; i <= n; ++i) {
//  for (int j = 1; j <= n; ++j) {
//  if (i != j && cost[i][j] < min) {
//  min = cost[i][j];
//  k = i;
//  l = j;
//  }
//  }
//  }
//  mincost = cost[k][l];
//  t[1][1] = k;
//  t[1][2] = l;
//  //Initialize near array
//  for (int i = 1; i <= n; ++i) {
//  if (cost[i][k] < cost[i][l]) {
//  near[i] = k;
//  } else {
//  near[i] = l;
//  }
//  }
//  near[k] = near[l] = 0;
//  //Find n-2 additional edges for t
//  for (int i = 2; i <= n - 1; ++i) {
//  // Find j such that near[j] != 0 and
// cost[j][near[j]] is minimum
//  int j = -1;
//  int min = INT_MAX;
//  for (int m = 1; m <= n; ++m) {
//  if (near[m] != 0 && cost[m][near[m]]
// < min) {
//  min = cost[m][near[m]];
//  j = m;
//  }
//  }
//  t[i][1] = j;
//  t[i][2] = near[j];
//  mincost = mincost + cost[j][near[j]];
//  near[j] = 0;
//  for (int k = 1; k <= n; ++k) {
//  if (near[k] != 0 && cost[k][near[k]] >
// cost[k][j]) {
//  near[k] = j;
//  }
//  }
//  }
//  return mincost;
// }
// int main() {
//  int n, e;
//  cout << "Enter the number of vertices: ";
//  cin >> n;
//  cout << "Enter the number of edges: ";
//  cin >> e;
//  int cost[MAX][MAX];
//  for (int i = 1; i <= n; i++) {
//  for (int j = 1; j <= n; j++) {
//  cost[i][j] = (i == j) ? INT_MAX :
// INT_MAX;
//  }
//  }
//  cout << "Enter edges (u, v) and their
// cost:\n";
//  for (int i = 0; i < e; i++) {
//  int u, v, c;
//  cin >> u >> v >> c;
//  cost[u][v] = c;
//  cost[v][u] = c;
//  }
//  int t[MAX][2];
//  int mincost = Prim(cost, n, t);
//  cout << "Edges in the Prim's Minimum
// Cost Spanning Tree and Their Cost :\n";
//  for (int i = 1; i <= n - 1; ++i) {
//  cout << "(" << t[i][1] << " , " << t[i][2] <<
// ") = "<<cost[t[i][1]][t[i][2]]<<endl;
//  }
//  cout << "Prim's Minimum cost: " <<
// mincost << endl;
//  return 0;
// }
// //12. Kruskal algorithm using greedy method
// #include <bits/stdc++.h>
// using namespace std;
// const int MAX = 100;
// int parent[MAX];
// int t[MAX][3];
// int Find(int u) {
//  if (parent[u] == -1)
//  return u;
//  return parent[u] = Find(parent[u]);
// }
// void Union(int u, int v) {
//  int parentU = Find(u);
//  int parentV = Find(v);
//  if (parentU != parentV) {
//  parent[parentU] = parentV;
//  }
// }
// void Heapify(int E[][2], int cost[][MAX], int m,
// int i) {
//  int smallest = i;
//  int left = 2 * i + 1;
//  int right = 2 * i + 2;
//  if (left < m && cost[E[left][0]][E[left][1]] <
// cost[E[smallest][0]][E[smallest][1]]) {
//  smallest = left;
//  }
//  if (right < m && cost[E[right][0]][E[right][1]]
// < cost[E[smallest][0]][E[smallest][1]]) {
//  smallest = right;
//  }
//  if (smallest != i) {
//  swap(E[i], E[smallest]);
//  Heapify(E, cost, m, smallest);
//  }
// }
// void Adjust(int E[][2], int cost[][MAX], int& m)
// {
//  if (m == 0) return;
//  swap(E[0], E[m - 1]);
//  m--;
//  Heapify(E, cost, m, 0);
// }
// int Kruskal(int E[][2], int cost[][MAX], int n,
// int m, int t[][3]) {
//  for (int i = m / 2 - 1; i >= 0; i--) {
//  Heapify(E, cost, m, i);
//  }
//  for (int i = 0; i < n; i++) {
//  parent[i] = -1;
//  }
//  int mincost = 0;
//  int i = 0;
//  while (i < n - 1 && m > 0) {
//  int u = E[0][0];
//  int v = E[0][1];
//  Adjust(E, cost, m);
//  int j = Find(u);
//  int k = Find(v);
//  if (j != k) {
//  i++;
//  t[i][0] = u;
//  t[i][1] = v;
//  t[i][2] = cost[u][v];
//  mincost += cost[u][v];
//  Union(j, k);
//  }
//  }
//  if (i != n - 1) {
//  cout << "No spanning tree" << endl;
//  return -1;
//  }
//  return mincost;
// }
// int main() {
//  int v, e;
//  cout << "Enter number of vertices and
// edges: ";
//  cin >> v >> e;
//  int E[MAX][2];
//  int cost[MAX][MAX];
//  for (int i = 0; i < MAX; i++) {
//  for (int j = 0; j < MAX; j++) {
//  cost[i][j] = 1e9;
//  }
//  }
//  cout << "Enter edges (u, v) and their
// cost:\n";
//  for (int i = 0; i < e; i++) {
//  int u, v, c;
//  cin >> u >> v >> c;
//  E[i][0] = u;
//  E[i][1] = v;
//  cost[u][v] = c;
//  cost[v][u] = c;
//  }
//  int mincost = Kruskal(E, cost, v, e, t);
//  if (mincost != -1) {
//  cout << "Minimum cost of the spanning
// tree: " << mincost << endl;
//  cout << "Edges in the minimum
// spanning tree:\n";
//  for (int i = 1; i <= v - 1; i++) {
//  cout << t[i][0] << " - " << t[i][1] << " : "
// << t[i][2] << endl;
//  }
//  }
//  return 0;
// }