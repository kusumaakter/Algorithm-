#include <bits/stdc++.h>
using namespace std;

const int N = 1e7;  
int a[N];

void interchange(int i, int j) {
    int temp = a[i];
    a[i] = a[j];
    a[j] = temp;
}

// Partition function
int partition(int m, int p) {
    int v = a[m]; 
    int i = m + 1;
    int j = p;

    do {
        while (i <= p && a[i] < v) {
            i++;
        }

        while (a[j] > v) {
            j--;
        }

        if (i < j) {
            interchange(i, j);
        }
    } while (i < j);

    interchange(m, j);  
    return j;  
}

void QuickSort(int m, int p) {
    if (m < p) {
        int q = partition(m, p);

        QuickSort(m, q - 1);  
        QuickSort(q + 1, p);  
    }
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    cout << "Enter " << n << " elements: ";
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    QuickSort(0, n - 1);  

    cout << "Sorted Array: ";
    for (int i = 0; i < n; i++) {
        cout << a[i] << ' ';
    }

    return 0;
}
