// #include <iostream>
// #include <limits.h>
// using namespace std;

// #define INF 999 // Representation of infinity

// void Prim(int cost[100][100], int n, int t[100][3], int &mincost) {
//     int near[100]; // Array to keep track of the nearest vertex

//     // Step 1: Find the edge (k, l) of minimum cost in the graph
//     int k, l, min = INF;
//     for (int i = 1; i <= n; i++) {
//         for (int j = 1; j <= n; j++) {
//             if (cost[i][j] < min) {
//                 min = cost[i][j];
//                 k = i;
//                 l = j;
//             }
//         }
//     }

//     // Add this edge to the MST
//     t[1][0] = k;
//     t[1][1] = l;
//     t[1][2] = cost[k][l];
//     mincost += cost[k][l];

//     // Initialize near array
//     for (int i = 1; i <= n; i++) {
//         if (cost[i][k] < cost[i][l])
//             near[i] = k;
//         else
//             near[i] = l;
//     }

//     near[k] = 0;
//     near[l] = 0;

//     // Step 2: Find n-2 additional edges for the MST
//     for (int i = 2; i <= n - 1; i++) {
//         int min = INF, j;

//         // Find the vertex j such that cost[j][near[j]] is minimum
//         for (int u = 1; u <= n; u++) {
//             if (near[u] != 0 && cost[u][near[u]] < min) {
//                 j = u;
//                 min = cost[u][near[u]];
//             }
//         }

//         // Add the edge to the MST
//         t[i][0] = j;
//         t[i][1] = near[j];
//         t[i][2] = cost[j][near[j]];
//         mincost += cost[j][near[j]];
//         near[j] = 0;

//         // Update the near array
//         for (int u = 1; u <= n; u++) {
//             if (near[u] != 0 && cost[u][near[u]] > cost[u][j]) {
//                 near[u] = j;
//             }
//         }
//     }
// }

// int main() {
//     int n, e; // Number of vertices and edges
//     int cost[100][100], t[100][3], mincost = 0;

//     cout << "Enter the number of vertices: ";
//     cin >> n;
//     cout << "Enter the number of edges: ";
//     cin >> e;

//     // Initialize the cost matrix with INF
//     for (int i = 1; i <= n; i++) {
//         for (int j = 1; j <= n; j++) {
//             cost[i][j] = (i == j) ? 0 : INF;
//         }
//     }

//     // Input the edges
//     cout << "Enter the edges (u, v) and their weights:" << endl;
//     for (int i = 0; i < e; i++) {
//         int u, v, w;
//         cin >> u >> v >> w;
//         cost[u][v] = w;
//         cost[v][u] = w; // Since the graph is undirected
//     }

//     // Run Prim's algorithm
//     Prim(cost, n, t, mincost);

//     // Display the minimum cost
//     cout << "Minimum cost: " << mincost << endl;

//     // Display the edges in the MST with their weights
//     cout << "Edges in the MST:" << endl;
//     for (int i = 1; i <= n - 1; i++) {
//         cout << "(" << t[i][0] << ", " << t[i][1] << ") = " << t[i][2] << endl;
//     }

//     return 0;
// }




// #include <iostream>
// #include <limits.h>
// using namespace std;

// #define INF INT_MAX // Representation of infinity

// void Prim(int cost[10][10], int n, int t[10][2]) {
//     int near[10]; // Array to keep track of the nearest vertex
//     int mincost = 0;

//     // Step 1: Find the edge (k, l) of minimum cost in the graph
//     int k, l, min = INF;
//     for (int i = 1; i <= n; i++) {
//         for (int j = 1; j <= n; j++) {
//             if (cost[i][j] < min) {
//                 min = cost[i][j];
//                 k = i;
//                 l = j;
//             }
//         }
//     }

//     // Add this edge to the MST
//     t[1][0] = k;
//     t[1][1] = l;
//     mincost += cost[k][l];

//     // Initialize near array
//     for (int i = 1; i <= n; i++) {
//         if (cost[i][k] < cost[i][l])
//             near[i] = k;
//         else
//             near[i] = l;
//     }

//     near[k] = 0;
//     near[l] = 0;

//     // Step 2: Find n-2 additional edges for the MST
//     for (int i = 2; i <= n - 1; i++) {
//         int min = INF, j;

//         // Find the vertex j such that cost[j][near[j]] is minimum
//         for (int u = 1; u <= n; u++) {
//             if (near[u] != 0 && cost[u][near[u]] < min) {
//                 j = u;
//                 min = cost[u][near[u]];
//             }
//         }

//         // Add the edge to the MST
//         t[i][0] = j;
//         t[i][1] = near[j];
//         mincost += cost[j][near[j]];
//         near[j] = 0;

//         // Update the near array
//         for (int u = 1; u <= n; u++) {
//             if (near[u] != 0 && cost[u][near[u]] > cost[u][j]) {
//                 near[u] = j;
//             }
//         }
//     }

//     // Display the results
//     cout << "Minimum cost: " << mincost << endl;
//     cout << "Edges in the MST:" << endl;
//     for (int i = 1; i <= n - 1; i++) {
//         cout << "(" << t[i][0] << ", " << t[i][1] << ") = cost(" << cost[t[i][0]][t[i][1]] << ")" << endl;
//     }
// }

// int main() {
//     int n, edges, cost[10][10], t[10][2];

//     cout << "Enter the number of vertices: ";
//     cin >> n;

//     // Initialize cost adjacency matrix with INF
//     for (int i = 1; i <= n; i++) {
//         for (int j = 1; j <= n; j++) {
//             cost[i][j] = (i == j) ? 0 : INF; // Diagonal elements are 0, others INF
//         }
//     }

//     cout << "Enter the number of edges: ";
//     cin >> edges;

//     cout << "Enter the edges (u v weight):" << endl;
//     for (int i = 0; i < edges; i++) {
//         int u, v, weight;
//         cin >> u >> v >> weight;
//         cost[u][v] = weight;
//         cost[v][u] = weight; // Since the graph is undirected
//     }

//     Prim(cost, n, t);

//     return 0;
// }


#include <iostream>
#include <limits.h>
using namespace std;

#define INF INT_MAX // Representation of infinity

void Prim(int cost[10][10], int n, int t[10][2]) {
    int near[10]; // Array to keep track of the nearest vertex
    int mincost = 0;

    // Step 1: Find the edge (k, l) of minimum cost in the graph
    int k, l, min = INF;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (cost[i][j] < min) {
                min = cost[i][j];
                k = i;
                l = j;
            }
        }
    }

    // Add this edge to the MST
    t[1][0] = k;
    t[1][1] = l;
    mincost += cost[k][l];

    // Initialize near array
    for (int i = 1; i <= n; i++) {
        if (cost[i][k] < cost[i][l])
            near[i] = k;
        else
            near[i] = l;
    }

    near[k] = 0;
    near[l] = 0;

    // Step 2: Find n-2 additional edges for the MST
    for (int i = 2; i <= n - 1; i++) {
        int min = INF, j;

        // Find the vertex j such that cost[j][near[j]] is minimum
        for (int u = 1; u <= n; u++) {
            if (near[u] != 0 && cost[u][near[u]] < min) {
                j = u;
                min = cost[u][near[u]];
            }
        }

        // Add the edge to the MST
        t[i][0] = j;
        t[i][1] = near[j];
        mincost += cost[j][near[j]];
        near[j] = 0;

        // Update the near array
        for (int u = 1; u <= n; u++) {
            if (near[u] != 0 && cost[u][near[u]] > cost[u][j]) {
                near[u] = j;
            }
        }
    }

    cout << "Minimum cost: " << mincost << endl;
    cout << "Edges in the MST:" << endl;
    for (int i = 1; i <= n - 1; i++) {
        cout << "(" << t[i][0] << ", " << t[i][1] << ")" << endl;
    }
}

int main() {
    int n, edges, cost[10][10], t[10][2];

    cout << "Enter the number of vertices: ";
    cin >> n;

    // Initialize cost adjacency matrix with INF
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            cost[i][j] = (i == j) ? 0 : INF; // Diagonal elements are 0, others INF
        }
    }

    cout << "Enter the number of edges: ";
    cin >> edges;

    cout << "Enter the edges (u v weight):" << endl;
    for (int i = 0; i < edges; i++) {
        int u, v, weight;
        cin >> u >> v >> weight;
        cost[u][v] = weight;
        cost[v][u] = weight; // Since the graph is undirected
    }

    Prim(cost, n, t);

    return 0;
}
